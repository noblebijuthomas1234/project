from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth  import authenticate,  login, logout
from django.contrib.auth.decorators import login_required
from . models import *
from django.views.generic import UpdateView
from .forms import *

def detail(request,id):
    c= course.objects.get(id=id)
    context={'c':c}
    return  render(request,'detail.html',context)

def college(request):
    # notice = Notice.objects.all()

    return render(request, "/admapp/college.html")

def index(request):
    c=course.objects.all()
    context={'courses':c}
    return render(request,'index.html',context)



def signup1(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/login")
            
    else:
        form = SignupForm()
    return render(request,'signup.html',{'form': form})

def apply1(request,pk):
    uid=request.session["user_id"]
    user=signup.objects.get(id=uid)
    cours=course.objects.get(id=pk)
    if request.method == 'POST':
        form = ApplyForm(request.POST)
        if form.is_valid():
            obj=form.save(commit=False)
            gender=request.POST["gender"]
            dob=request.POST["DOB"]
            if cours.is_exam == True:
                obj.entrance=request.POST["entrance"]
            obj.dob=dob
            obj.gender=gender
            obj.cour=cours
            obj.user=user
            obj.save()
            return redirect("/")
    else:
        form = ApplyForm()

    return render(request, 'apply.html', {'form': form,'c':cours})

def book(request):
    uid=request.session["user_id"]
    user=signup.objects.get(id=uid)
    applied=apply.objects.filter(user=user)
    context={'app':applied}
    return render(request,'booking.html',context)



def login(request):
    if request.method == 'POST':
        un = request.POST.get('email')
        pwd = request.POST.get('password')

        ul = signup.objects.filter(email=un, password=pwd)
        print(ul)
       
        #user_type = userlogin.objects.filter(user_type = 'user')
        if ul:
            request.session['user_name'] = ul[0].email
            request.session['user_id'] = ul[0].id
            return redirect("/")

        
        else:
            context ={ 'msg':'Invalid username and password...!'}
            return render(request,'studentlogin.html',context)

    else:
        return render(request,'studentlogin.html')

    
def logout(request):

    try:
        del request.session['user_name']

        del request.session['user_id']
    except:
         return redirect("/")
    else:
        return redirect("/")
    
def cancel(request,id):
    can=apply.objects.get(id=id)
    can.delete()
    return redirect("http://127.0.0.1:8000/book")