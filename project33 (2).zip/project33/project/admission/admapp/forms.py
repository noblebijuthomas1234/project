from django import forms
from .models import *

class SignupForm(forms.ModelForm):
    class Meta:
        model = signup
        fields = ['fname', 'lname', 'email', 'password']

        widgets = {
                'fname': forms.TextInput(attrs={'class': 'input-class1', 'placeholder': 'First Name'}),
                'lname': forms.TextInput(attrs={'class': 'input-class2', 'placeholder': 'Last Name'}),
                'email': forms.EmailInput(attrs={'class': 'input-class3', 'placeholder': 'Email Address'}),
                'password': forms.PasswordInput(attrs={'class': 'input-class4', 'placeholder': 'Password'}),
            }



class ApplyForm(forms.ModelForm):
    class Meta:
        model = apply
        fields = [ 'father', 'mother', 'address', 'ten', 'twelve']
        widgets = {
            
            'father': forms.TextInput(attrs={'class': 'input-class', 'placeholder': 'Father\'s Name'}),
            'mother': forms.TextInput(attrs={'class': 'input-class', 'placeholder': 'Mother\'s Name'}),
            
           
            'address': forms.TextInput(attrs={'class': 'input-class', 'placeholder': 'Address'}),
            'ten': forms.NumberInput(attrs={'class': 'input-class', 'placeholder': '10th Grade'}),
            'twelve': forms.NumberInput(attrs={'class': 'input-class', 'placeholder': '12th Grade'}),
            'entrance': forms.NumberInput(attrs={'class': 'input-class', 'placeholder': 'Entrance Exam Score'}),
        }