from django.contrib import admin
from.models import *


admin.site.register(signup)
admin.site.register(course)
admin.site.register(apply)


