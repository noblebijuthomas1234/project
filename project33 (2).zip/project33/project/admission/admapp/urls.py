from django.urls import path
from . import views



urlpatterns = [
    path("", views.index, name="college"),
    path('login',views.login,name="login"),
    path('signup',views.signup1,name="signup"),
    path('apply/<int:pk>',views.apply1),
    path('book',views.book),
    path('logout',views.logout,name="logout"),
    path('cancel/<int:id>',views.cancel),
    path('detail/<int:id>',views.detail)
    
]