from django.db import models
from django.contrib.auth import get_user_model
User=get_user_model()


    


class admin_login(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)



class Register(models.Model):
     user=models.ForeignKey(User,on_delete=models.CASCADE)
     first_name = models.CharField(max_length=30)
     last_name = models.CharField(max_length=30)
     
     DOB = models.IntegerField(max_length=15)
     gender = models.CharField(max_length=10)
     email = models.CharField(max_length=20)
     
     Address = models.CharField(max_length=20)
     City = models.CharField(max_length=20)
     State = models.CharField(max_length=20)
     phone = models.IntegerField(default=0)


     def __str__(self):
         return self.first_name


class college(models.Model):
    CollegeName = models.CharField(max_length=20)
    Address = models.CharField(max_length=20)
    phone = models.IntegerField(default=0)
    email = models.CharField(max_length=20)
    City = models.CharField(max_length=20)
    State = models.CharField(max_length=20)


class course(models.Model):
    college=models.ForeignKey(college,on_delete=models.DO_NOTHING)
    couse_name = models.CharField(max_length=20)
    max_percentage_required = models.IntegerField(null=True)
    max_student_capacity = models.IntegerField(null=True)
    is_exam=models.BooleanField(default=False,)
    outcome=models.CharField(max_length=300,null=True)

    Last_year_Qualification_required = models.CharField(max_length=20)

    def __str__(self):
        return  self.couse_name
    

class college_application(models.Model):
     college=models.ForeignKey(college,on_delete=models.DO_NOTHING)
     course=models.ForeignKey(course,on_delete=models.DO_NOTHING)
     user=models.ForeignKey(User,on_delete=models.DO_NOTHING)
     Date_applied = models.DateTimeField(max_length=20)
     status = models.CharField(max_length=20)


class Cut_off(models.Model):
     college=models.ForeignKey(college,on_delete=models.DO_NOTHING)
     course=models.ForeignKey(course,on_delete=models.DO_NOTHING)
     second_last_year = models.IntegerField(max_length=20)
     last_year = models.IntegerField
     max_number_of_students = models.IntegerField(max_length=20)
     list_no = models.IntegerField



#newly created
class signup(models.Model):
     fname=models.CharField(max_length=100)
     lname=models.CharField(max_length=100)
     email=models.CharField(max_length=100)
     password=models.CharField(max_length=100)
     def __str__(self):
         return self.fname



class apply(models.Model):
     cour=models.ForeignKey(course,on_delete=models.CASCADE)
     user=models.ForeignKey(signup,on_delete=models.CASCADE)
     father=models.CharField(max_length=100)
     mother=models.CharField(max_length=100)
     dob=models.DateField()
     gender=models.CharField(max_length=10)
     address=models.CharField(max_length=100)
     ten=models.IntegerField()
     twelve=models.IntegerField()
     entrance=models.IntegerField(null=True,blank=True)
     applied_on=models.DateTimeField(auto_now=True)
     STATUS_CHOICES = (
         ('PENDING', 'Pending'),
         ('APPROVED', 'Approved'),
         ('REJECTED', 'Rejected'),
     )
     status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='PENDING')







#end

    
    


